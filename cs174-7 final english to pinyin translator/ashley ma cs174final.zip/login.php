<?php
// login.php
    $hn = 'localhost';
	$un = 'ashleyma';
	$pw = '458b8q88l3uy+m@';
	$db = 'assignment';
?>